
rootProject.name="backend"

